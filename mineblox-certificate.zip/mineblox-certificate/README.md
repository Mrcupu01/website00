# Mineblox Certificate Generator

Generator sertifikat komunitas sederhana menggunakan Flask. Tidak memakai login, dashboard admin, atau database.

## Fitur
- Custom nama, judul, kalimat pembuka, deskripsi, periode, tanggal, komunitas, dan penandatangan.
- Preview langsung.
- Download PDF A4 landscape dan PNG.
- QR berisi ID sertifikat (bukan verifikasi online).

## Instalasi di Linux

```bash
cd mineblox-certificate
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Buka `http://127.0.0.1:5000` di browser.

## Catatan
Sertifikat ini merupakan desain komunitas/hiburan. QR hanya memuat ID sertifikat dan tidak terhubung ke layanan verifikasi online.
